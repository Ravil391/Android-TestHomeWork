package com.ShapeShifter420.myapplication.Interfaces

interface ILogger {
    fun log(tag:String,text:String)
}